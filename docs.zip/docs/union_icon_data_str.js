var union_icon_data_str =
[
    [ "buffer", "union_icon_data_str.html#a0361d93d924d63df352808d9e47a38c6", null ],
    [ "buffLen", "union_icon_data_str.html#a2b0b5de5f8159449befe7ca7eea05e87", null ],
    [ "indirectSprite", "union_icon_data_str.html#a29152408180b8e0b9b1c06a6bbb4110c", null ],
    [ "indirectText", "union_icon_data_str.html#afc3e40687c1aaca4d907e7befd5655dd", null ],
    [ "name", "union_icon_data_str.html#a0348107b61cb0e144df0ffc28c840a51", null ],
    [ "nameisname", "union_icon_data_str.html#ade616986a7bceda36fbd8dd8d7bafc63", null ],
    [ "sprite_name", "union_icon_data_str.html#a17e9f8f31ef5b4608d4c55d4e2816b82", null ],
    [ "spritearea", "union_icon_data_str.html#a5383f8abce7285f8c9cb24de8a8287c4", null ],
    [ "text", "union_icon_data_str.html#a79fc900baa891cba8dad12f0a46229f2", null ],
    [ "validString", "union_icon_data_str.html#a5e216778b133e58a2e5f29be030cfaa0", null ]
];