var struct_open_window_str =
[
    [ "behind", "struct_open_window_str.html#ad0eff76bf6cf097b45c41dbd06b44966", null ],
    [ "box", "struct_open_window_str.html#a7130e370e9ef0094738625cd28ccb181", null ],
    [ "handle", "struct_open_window_str.html#af00d706f0a91e65f835172ab76c97b2a", null ],
    [ "offset", "struct_open_window_str.html#a2e365a2177bc76a3106709942fb90206", null ]
];