var class_sprite_obj =
[
    [ "SpriteObj", "class_sprite_obj.html#ac688f9a6a9a5c9cf3f12ca3f7dd897f0", null ],
    [ "SpriteObj", "class_sprite_obj.html#ae18c457f4c94de859c179dc93d101893", null ],
    [ "~SpriteObj", "class_sprite_obj.html#ade5677bd39d8a9af24fbf13e4c48979b", null ],
    [ "getClassName", "class_sprite_obj.html#a3d1a6aa42cafbcc6ea8f76107688b4d2", null ],
    [ "getClassType", "class_sprite_obj.html#a8ff5fa2c2d2a2f865e454909b2f4b0d2", null ],
    [ "getScaleFactors", "class_sprite_obj.html#ad55a18a6e56787c9c9019dfd7da8c86c", null ],
    [ "getSpritePtr", "class_sprite_obj.html#a2b49442e3f15f72b6d584816c09b4e8c", null ],
    [ "setScaleFactors", "class_sprite_obj.html#ae1a026688f3f76b34ab6f2a959f881a4", null ],
    [ "setSpritePtr", "class_sprite_obj.html#a4fd9aa5f10354dce3ac082b4c80bcfd7", null ],
    [ "showProperties", "class_sprite_obj.html#a7b90ffcb6f8e180ba271aef7ff42533b", null ]
];