var struct_pointer_leaving_window_block =
[
    [ "w", "struct_pointer_leaving_window_block.html#ab059c4ef82283e30274a166c18525175", null ]
];