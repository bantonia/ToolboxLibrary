var class_object =
[
    [ "Object", "class_object.html#a40860402e64d8008fb42329df7097cdb", null ],
    [ "~Object", "class_object.html#ae8f5483f459e46687bd01e6f9977afd3", null ],
    [ "getClassName", "class_object.html#a0017577aa3349d6e361e0f171adecd35", null ],
    [ "getClassType", "class_object.html#a0f0f76a055d69bd2550311608745e104", null ],
    [ "showProperties", "class_object.html#ab93aa73d7ba17027c5d83b1c6198a0cd", null ]
];