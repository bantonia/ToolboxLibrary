var class_colour_trans_obj =
[
    [ "ColourTransObj", "class_colour_trans_obj.html#a543d8491879556d67145ccb02329c7b6", null ],
    [ "~ColourTransObj", "class_colour_trans_obj.html#a4cd5fc61c6de73e4075f8df432833521", null ],
    [ "getClassName", "class_colour_trans_obj.html#a2dbb1bb8017e96684583868c0f61f155", null ],
    [ "getClassType", "class_colour_trans_obj.html#a740675f7705c6df0a906c954af0e423d", null ],
    [ "showProperties", "class_colour_trans_obj.html#a2d2a40d1b151d0d46e6cdc744cd0d8b9", null ],
    [ "Flags", "class_colour_trans_obj.html#aed4832ed1df17c9f95c5ee82aa7550f9", null ]
];