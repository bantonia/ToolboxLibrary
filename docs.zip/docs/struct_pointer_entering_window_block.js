var struct_pointer_entering_window_block =
[
    [ "w", "struct_pointer_entering_window_block.html#a6ff3c67fb294c90c96214e7bc931d6df", null ]
];