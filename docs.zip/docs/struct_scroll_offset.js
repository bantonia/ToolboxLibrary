var struct_scroll_offset =
[
    [ "x", "struct_scroll_offset.html#a6b6012316fa7ec651713ca72ea7b58ac", null ],
    [ "y", "struct_scroll_offset.html#aeea99f6f9d694d41322524dfab8d885a", null ]
];