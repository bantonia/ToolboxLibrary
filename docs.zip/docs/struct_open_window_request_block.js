var struct_open_window_request_block =
[
    [ "behind", "struct_open_window_request_block.html#a54a5b5d04f061b910ec46b5357d49cdb", null ],
    [ "box", "struct_open_window_request_block.html#a02583ee479c2e19505a7b0a9fd3b4c1b", null ],
    [ "offset", "struct_open_window_request_block.html#a8a1865476ff0d2b280d2b30b5f5b4ca8", null ],
    [ "w", "struct_open_window_request_block.html#a0d038bfda97e934268720ab36e35255b", null ]
];