var struct_box =
[
    [ "maxX", "struct_box.html#ac10ce511c0bbe232d25b5492a8747a44", null ],
    [ "maxY", "struct_box.html#aa5dd8510ac02dfcd4c7e8cbfd403073c", null ],
    [ "minX", "struct_box.html#a4220bf6a9af7fa2c160dcb7d3dccfa9c", null ],
    [ "minY", "struct_box.html#a5be2c6dad21175dfea0083c6858d225b", null ]
];