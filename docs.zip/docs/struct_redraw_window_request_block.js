var struct_redraw_window_request_block =
[
    [ "box", "struct_redraw_window_request_block.html#a1453f8b1c4175793040b0670dec10674", null ],
    [ "w", "struct_redraw_window_request_block.html#ae7b049d43fb98b25009b3a5e4c4b5178", null ]
];