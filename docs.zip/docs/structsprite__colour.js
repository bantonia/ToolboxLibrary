var structsprite__colour =
[
    [ "colour", "structsprite__colour.html#acd877d4df5020311fbd47a1357c6dc12", null ],
    [ "tint", "structsprite__colour.html#a4476b8ca5c184fbdc5cddfcd12588963", null ]
];