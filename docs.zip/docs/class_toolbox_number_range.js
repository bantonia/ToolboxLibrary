var class_toolbox_number_range =
[
    [ "ToolboxNumberRange", "class_toolbox_number_range.html#a6216111c7b47b6349a0e67c9589f3fa4", null ],
    [ "ToolboxNumberRange", "class_toolbox_number_range.html#ab8c05a32a7db6c5c1fdd36f4c06b4807", null ],
    [ "ToolboxNumberRange", "class_toolbox_number_range.html#aa7d7f44409b8544b7d4c43141211cfe3", null ],
    [ "gadgetMethod", "class_toolbox_number_range.html#a2b435a6feb963affdb430c429029024b", null ],
    [ "getBounds", "class_toolbox_number_range.html#a1f36bf3feb37813c640398db3cf8efa7", null ],
    [ "getClassName", "class_toolbox_number_range.html#aa213dce5cf22452f12d61321a2dde2a5", null ],
    [ "getClassType", "class_toolbox_number_range.html#a208a712174d2f642194f81af1d44e075", null ],
    [ "getComponents", "class_toolbox_number_range.html#adc91193c1225498d6bd0fdc3e5ac6b56", null ],
    [ "getValue", "class_toolbox_number_range.html#a28db164322bd5ae3275636efae6dfe4a", null ],
    [ "moveGadget", "class_toolbox_number_range.html#a87ef4c13067b058ec42e5802c19361d7", null ],
    [ "setBounds", "class_toolbox_number_range.html#ab9bd3798a3307dfb212792a19abfc189", null ],
    [ "setComponentId", "class_toolbox_number_range.html#a1029752e49c04106f68e6278e6ebc136", null ],
    [ "setFlags", "class_toolbox_number_range.html#ad86c38e58865fcd9032b9e7a33e3c0bc", null ],
    [ "setFocus", "class_toolbox_number_range.html#a5c9b06b660c3e29da36dcc7d27a9c144", null ],
    [ "setGadgetFlags", "class_toolbox_number_range.html#ab0566c0189abe0dab1f53135e8e7a712", null ],
    [ "setHelpMessage", "class_toolbox_number_range.html#adf237b961fb1d7f57ed55707289c5864", null ],
    [ "setObjectId", "class_toolbox_number_range.html#a191a88d4f7244ccd73cf3059558cea7c", null ],
    [ "setValue", "class_toolbox_number_range.html#aaf1a8be06994b48e10c631c9e1afcbde", null ],
    [ "showProperties", "class_toolbox_number_range.html#a07c596af79fb0654b36e5a627419486f", null ]
];