var union_wimp_palette_word =
[
    [ "blue", "union_wimp_palette_word.html#a7494ae3a231535adf4a2f4cf1af0f6c7", null ],
    [ "bytes", "union_wimp_palette_word.html#a6dbdc6ae8eb4ad149c695ac1134d68e6", null ],
    [ "bytes", "union_wimp_palette_word.html#a46948895bd44d468436172721766637c", null ],
    [ "gcol", "union_wimp_palette_word.html#a88ef930c0509ec10ac7055648bd607d6", null ],
    [ "green", "union_wimp_palette_word.html#acec534a71cc60d37b1f85d8f6da6c5d9", null ],
    [ "red", "union_wimp_palette_word.html#aa39ef484af37a344c50c5564665c5bcb", null ],
    [ "word", "union_wimp_palette_word.html#aef50c57414d2756040d5e60a2e068a52", null ]
];