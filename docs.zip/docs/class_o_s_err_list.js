var class_o_s_err_list =
[
    [ "OSErrList", "class_o_s_err_list.html#a65306a276acd369c3c270c3836d52e32", null ],
    [ "OSErrList", "class_o_s_err_list.html#af78fd64faa4cd13e9933c21da6647cff", null ],
    [ "~OSErrList", "class_o_s_err_list.html#a861369c1b90c4adee5759229b5c4e7b9", null ],
    [ "addError", "class_o_s_err_list.html#a32da8c9b9698676b36165ae4aadcab67", null ],
    [ "getClassName", "class_o_s_err_list.html#a9fbded2c635b2c673aa49bc1d426996c", null ],
    [ "getClassType", "class_o_s_err_list.html#af49704f8cc099fb64caec54a318eac76", null ],
    [ "getNext", "class_o_s_err_list.html#a9e77d69430d536f5578ea125a0ef5e9a", null ],
    [ "reportErrors", "class_o_s_err_list.html#a4c631bd03a99176163daaef12796557c", null ],
    [ "showProperties", "class_o_s_err_list.html#aa3d64e35918ba9cbbccc7e2872c5a264", null ]
];