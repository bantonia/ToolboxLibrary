var struct_mouse_click_block =
[
    [ "b", "struct_mouse_click_block.html#a2f093ce281be365fe0c24d0a077e8ab7", null ],
    [ "i", "struct_mouse_click_block.html#ad3001d65c8482cfa05b06e7737f42640", null ],
    [ "w", "struct_mouse_click_block.html#a7f4829b5c4c29e3469f08a5c6482d389", null ],
    [ "x", "struct_mouse_click_block.html#a30e76ad4d7bcff85df2f3645be574a91", null ],
    [ "y", "struct_mouse_click_block.html#aab54adb9e308ae6a8ec02f75243fcf49", null ]
];