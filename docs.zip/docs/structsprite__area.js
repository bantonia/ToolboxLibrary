var structsprite__area =
[
    [ "freeoff", "structsprite__area.html#a858acc2729431303ac0406ff1e0183ff", null ],
    [ "number", "structsprite__area.html#a8f318b429d10cf4ca30b075f44189200", null ],
    [ "size", "structsprite__area.html#a94ff08caab43bc8bde2b791b1d9c6e52", null ],
    [ "sproff", "structsprite__area.html#a9d8af97fc8369d75a5f77fd7ea4ca065", null ]
];