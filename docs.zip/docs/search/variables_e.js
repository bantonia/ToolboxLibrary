var searchData=
[
  ['offset_0',['offset',['../struct_open_window_request_block.html#a8a1865476ff0d2b280d2b30b5f5b4ca8',1,'OpenWindowRequestBlock::offset'],['../struct_scroll_request_block.html#ae34ba8afe34ec3c1cf6a41a30696047f',1,'ScrollRequestBlock::offset'],['../struct_wind_def_str.html#a8fdea91a5a6bd67321574e32b8e9c903',1,'WindDefStr::offset'],['../struct_open_window_str.html#a2e365a2177bc76a3106709942fb90206',1,'OpenWindowStr::offset']]]
];
