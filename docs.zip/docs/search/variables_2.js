var searchData=
[
  ['b_0',['b',['../struct_toolbox_colour_dlog_obj_1_1colour_block_hdr.html#a265ddad6a8c3b55163ce45b0e4daa6e8',1,'ToolboxColourDlogObj::colourBlockHdr::b'],['../union_wimp_mask.html#ad82dd7f8d620157b5d11d24e6c8ecd35',1,'WimpMask::b'],['../struct_mouse_click_block.html#a2f093ce281be365fe0c24d0a077e8ab7',1,'MouseClickBlock::b'],['../union_window_flags.html#aec894a3d56a962f98accb05331c2637b',1,'WindowFlags::b'],['../union_icon_flags.html#ab87069bd8b15c6b039c0c8a0ab136b76',1,'IconFlags::b']]],
  ['background_1',['background',['../union_icon_flags.html#ad23e6e33076ebd2c9bf9b25ee2b8ec2b',1,'IconFlags']]],
  ['behind_2',['behind',['../struct_open_window_request_block.html#a54a5b5d04f061b910ec46b5357d49cdb',1,'OpenWindowRequestBlock::behind'],['../struct_scroll_request_block.html#a55520a04907cac0d0afc4ffc2275039b',1,'ScrollRequestBlock::behind'],['../struct_wind_def_str.html#ad5127a9b0d50dacd4378f76e7c64cd12',1,'WindDefStr::behind'],['../struct_open_window_str.html#ad0eff76bf6cf097b45c41dbd06b44966',1,'OpenWindowStr::behind']]],
  ['blue_3',['blue',['../union_wimp_palette_word.html#a7494ae3a231535adf4a2f4cf1af0f6c7',1,'WimpPaletteWord::blue'],['../struct_toolbox_colour_dlog_obj_1_1colour_block_hdr.html#ae2a3eee61b99496044b60afef7f8df16',1,'ToolboxColourDlogObj::colourBlockHdr::blue']]],
  ['box_4',['box',['../struct_redraw_window_request_block.html#a1453f8b1c4175793040b0670dec10674',1,'RedrawWindowRequestBlock::box'],['../struct_open_window_request_block.html#a02583ee479c2e19505a7b0a9fd3b4c1b',1,'OpenWindowRequestBlock::box'],['../struct_scroll_request_block.html#a09100654ddc7178021a649d3c0a51b1f',1,'ScrollRequestBlock::box'],['../struct_open_window_str.html#a7130e370e9ef0094738625cd28ccb181',1,'OpenWindowStr::box']]],
  ['buffer_5',['buffer',['../union_icon_data_str.html#a0361d93d924d63df352808d9e47a38c6',1,'IconDataStr']]],
  ['bufflen_6',['buffLen',['../union_icon_data_str.html#a2b0b5de5f8159449befe7ca7eea05e87',1,'IconDataStr']]],
  ['buttontype_7',['buttonType',['../union_icon_flags.html#a06e71434704c577e500cf60b618ab2aa',1,'IconFlags']]],
  ['bytes_8',['bytes',['../union_wimp_palette_word.html#a6dbdc6ae8eb4ad149c695ac1134d68e6',1,'WimpPaletteWord::bytes'],['../union_wimp_palette_word.html#a46948895bd44d468436172721766637c',1,'WimpPaletteWord::bytes']]]
];
