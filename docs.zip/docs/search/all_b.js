var searchData=
[
  ['lbit_0',['lbit',['../structsprite__header.html#a44efd538d9a1f4ba4e9149f75f60af40',1,'sprite_header']]],
  ['loadspritefile_1',['loadSpriteFile',['../class_sprite_area_obj.html#ab110a7819c6844a143ee8beed4d56474',1,'SpriteAreaObj']]],
  ['losecaret_2',['loseCaret',['../union_wimp_mask.html#a3975b74daa1978938b04afa6b353c01f',1,'WimpMask::loseCaret'],['../class_wimp_obj.html#a66a65b76537eca36f6e1ea5fc4ccb984',1,'WimpObj::loseCaret()']]]
];
