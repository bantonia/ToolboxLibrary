var searchData=
[
  ['handle_0',['handle',['../struct_open_window_str.html#af00d706f0a91e65f835172ab76c97b2a',1,'OpenWindowStr']]],
  ['hasadjusticon_1',['hasAdjustIcon',['../union_window_flags.html#a25bedba5754098f73cb39b2acfb1e605',1,'WindowFlags']]],
  ['hasbackicon_2',['hasBackIcon',['../union_window_flags.html#a8884a73b8b2cefdc80ca252e6658e6fb',1,'WindowFlags']]],
  ['hasborder_3',['hasBorder',['../union_icon_flags.html#aa7d9e550c374542a75b8be57fcad1987',1,'IconFlags']]],
  ['hascloseicon_4',['hasCloseIcon',['../union_window_flags.html#ade64970c5c2107685a47f3dea9f85d97',1,'WindowFlags']]],
  ['hashscroll_5',['hasHScroll',['../union_window_flags.html#a906cb386610a9236f64e5c7cbebb3d90',1,'WindowFlags']]],
  ['hashscrollbar_6',['hasHScrollBar',['../union_window_flags.html#ae20842279406628ee995714917e1fb01',1,'WindowFlags']]],
  ['hastitlebar_7',['hasTitleBar',['../union_window_flags.html#a8bf936c78ffb528a622868e3cfe84cfd',1,'WindowFlags']]],
  ['hastoggleicon_8',['hasToggleIcon',['../union_window_flags.html#a06c28bc9803fac162fbcf8556791bb1d',1,'WindowFlags']]],
  ['hasvscroll_9',['hasVScroll',['../union_window_flags.html#a0b582f11d58a3b275c8b346b02ffb173',1,'WindowFlags']]],
  ['hasvscrollbar_10',['hasVScrollBar',['../union_window_flags.html#a5452aa7b2efb62698dddfa1551bc0b5a',1,'WindowFlags']]],
  ['height_11',['height',['../structsprite__header.html#a4d72ca35b7a4c8daf8c977beb6ef2b8e',1,'sprite_header::height'],['../structsprite__info.html#a2083da83c773b4986949000f7741922b',1,'sprite_info::height'],['../struct_sprite_area_obj_1_1sprite_info__t.html#adb518f049809b72b34563f25533cb121',1,'SpriteAreaObj::spriteInfo_t::height'],['../struct_wind_def_str.html#a08e63ceae4f54104b3e327fc8f999f77',1,'WindDefStr::height']]]
];
