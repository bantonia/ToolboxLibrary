var searchData=
[
  ['pointerenteringwindowblock_0',['PointerEnteringWindowBlock',['../struct_pointer_entering_window_block.html',1,'']]],
  ['pointerleavingwindowblock_1',['PointerLeavingWindowBlock',['../struct_pointer_leaving_window_block.html',1,'']]]
];
