var searchData=
[
  ['addr_0',['addr',['../structsprite__id.html#ac11dca3f9ca428bb62f1f4c008089ef3',1,'sprite_id']]],
  ['allowscrollrequest_1',['allowScrollRequest',['../union_window_flags.html#a47acb003c935ac042fe16735deba39b7',1,'WindowFlags']]],
  ['alwaysbelow_2',['alwaysBelow',['../union_window_flags.html#a18116d41552fead042d26c8798d2a678',1,'WindowFlags']]]
];
