var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwxy~",
  1: "bceikmoprstw",
  2: "abcdefghiklmnopqrstuw~",
  3: "_abcdefghiklmnopqrstuvwxy",
  4: "sw",
  5: "ce",
  6: "chrsuw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator"
};

