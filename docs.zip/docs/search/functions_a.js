var searchData=
[
  ['loadspritefile_0',['loadSpriteFile',['../class_sprite_area_obj.html#ab110a7819c6844a143ee8beed4d56474',1,'SpriteAreaObj']]],
  ['losecaret_1',['loseCaret',['../class_wimp_obj.html#a66a65b76537eca36f6e1ea5fc4ccb984',1,'WimpObj']]]
];
