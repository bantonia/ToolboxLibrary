var searchData=
[
  ['name_0',['name',['../structsprite__header.html#add5edbf7ce57dcfd33bf039825ed1a94',1,'sprite_header::name'],['../structsprite__id.html#abcc66e6783439338c5ed6fc7a5b463c9',1,'sprite_id::name'],['../union_icon_data_str.html#a0348107b61cb0e144df0ffc28c840a51',1,'IconDataStr::name']]],
  ['nameisname_1',['nameisname',['../union_icon_data_str.html#ade616986a7bceda36fbd8dd8d7bafc63',1,'IconDataStr']]],
  ['next_2',['next',['../structsprite__header.html#a0646e3cecede790c63ee19f1655723fb',1,'sprite_header']]],
  ['noautorepeat_3',['noAutoRepeat',['../union_window_flags.html#a1aa92740c3a538486e618a1bf46528d3',1,'WindowFlags']]],
  ['nobackcloseicons_4',['noBackCloseIcons',['../union_window_flags.html#a7e081f49053aaec5479b5686b6752fbf',1,'WindowFlags']]],
  ['nullreason_5',['nullReason',['../class_wimp_obj.html#a9c3034e495e0b32102afec03c3f70e30',1,'WimpObj']]],
  ['nullreasoncode_6',['nullReasonCode',['../union_wimp_mask.html#aab096a2341eed1227b53eabc405110ab',1,'WimpMask']]],
  ['number_7',['number',['../structsprite__area.html#a8f318b429d10cf4ca30b075f44189200',1,'sprite_area']]],
  ['numberrangevaluechanged_8',['numberRangeValueChanged',['../class_toolbox_core_obj.html#a2cffc0aa273fcfbf2047271d3cdc13ca',1,'ToolboxCoreObj']]],
  ['numbits_9',['numBits',['../class_bit_field.html#ac6bf8b8b3ca4ade272c894f59d43e148',1,'BitField']]],
  ['numicons_10',['numIcons',['../struct_wind_def_str.html#a62dff20e0701a941d9a8bf7c1c4d4513',1,'WindDefStr']]]
];
