var searchData=
[
  ['winddefstr_0',['WindDefStr',['../class_wimp_obj.html#a4e784376e8f1ea97bdc62802903cfbcc',1,'WimpObj']]],
  ['windowobjflags_1',['WindowObjFlags',['../class_wimp_window_obj.html#adfdb32cb44101cc48eafbdf2f95e9e85',1,'WimpWindowObj']]]
];
