var searchData=
[
  ['r_0',['r',['../structsprite__state.html#ad2ac2b693f88cfc4513a214650db4d2e',1,'sprite_state']]],
  ['rbit_1',['rbit',['../structsprite__header.html#a2ca2d016ad9274ab7e140fe52b8324cd',1,'sprite_header']]],
  ['red_2',['red',['../union_wimp_palette_word.html#aa39ef484af37a344c50c5564665c5bcb',1,'WimpPaletteWord::red'],['../struct_toolbox_colour_dlog_obj_1_1colour_block_hdr.html#aeb8d9b80f382556b8b203f9c536fe22d',1,'ToolboxColourDlogObj::colourBlockHdr::red']]],
  ['redrawwindowrequest_3',['redrawWindowRequest',['../union_wimp_mask.html#ab752106358879382b87eab2152f79663',1,'WimpMask']]],
  ['requiresredrawhelp_4',['requiresRedrawHelp',['../union_icon_flags.html#a251b97df06f413b7ca3dde20293f00b3',1,'IconFlags']]],
  ['reserved_5',['reserved',['../struct_wind_def_str.html#ae9ddcbc823775dc6cd697fb3d6cb7bfe',1,'WindDefStr']]]
];
