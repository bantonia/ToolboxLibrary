var searchData=
[
  ['setbackground_0',['SetBackground',['../class_colour_trans_obj.html#aa90180501612b668c2ac0797a5205574afcfc54a50c187d20d78449422a729119',1,'ColourTransObj']]],
  ['setforeground_1',['SetForeground',['../class_colour_trans_obj.html#aa90180501612b668c2ac0797a5205574a9a70996fc678bdc807d94d08e404248b',1,'ColourTransObj']]]
];
