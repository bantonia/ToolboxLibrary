var searchData=
[
  ['x_0',['x',['../struct_scroll_offset.html#a6b6012316fa7ec651713ca72ea7b58ac',1,'ScrollOffset::x'],['../struct_mouse_click_block.html#a30e76ad4d7bcff85df2f3645be574a91',1,'MouseClickBlock::x']]],
  ['x0_1',['x0',['../structsprite__box.html#ac7fc838789ed8d952ca6d43d2654eb6f',1,'sprite_box']]],
  ['x1_2',['x1',['../structsprite__box.html#ac107090547938e9b8951e29772bd7d8f',1,'sprite_box']]],
  ['xdiv_3',['xdiv',['../structsprite__factors.html#a4308e455cdb9b4f980c8b98f48bdb448',1,'sprite_factors']]],
  ['xmag_4',['xmag',['../structsprite__factors.html#a5bf8eaeebad4465afad15b25b69b2304',1,'sprite_factors']]],
  ['xoffset_5',['xOffset',['../struct_key_pressed_block.html#a0054950afd9663fc0dd19a34de411e24',1,'KeyPressedBlock']]]
];
