var searchData=
[
  ['validstring_0',['validString',['../union_icon_data_str.html#a5e216778b133e58a2e5f29be030cfaa0',1,'IconDataStr']]],
  ['visiblearea_1',['visibleArea',['../struct_wind_def_str.html#ab74a6c00eb02d19af3c9c86c2801d3d0',1,'WindDefStr']]]
];
