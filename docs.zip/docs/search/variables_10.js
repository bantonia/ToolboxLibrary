var searchData=
[
  ['quit_0',['quit',['../class_wimp_obj.html#ae1d97f0182501f6c696937c92a65f2c7',1,'WimpObj']]]
];
