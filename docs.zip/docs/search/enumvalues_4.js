var searchData=
[
  ['useecf_0',['UseECF',['../class_colour_trans_obj.html#aa90180501612b668c2ac0797a5205574ab591e564d44dfdb4e4dc01cf635bb17f',1,'ColourTransObj']]]
];
