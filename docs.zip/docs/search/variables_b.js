var searchData=
[
  ['lbit_0',['lbit',['../structsprite__header.html#a44efd538d9a1f4ba4e9149f75f60af40',1,'sprite_header']]],
  ['losecaret_1',['loseCaret',['../union_wimp_mask.html#a3975b74daa1978938b04afa6b353c01f',1,'WimpMask']]]
];
