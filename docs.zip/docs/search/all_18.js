var searchData=
[
  ['y_0',['y',['../struct_scroll_offset.html#aeea99f6f9d694d41322524dfab8d885a',1,'ScrollOffset::y'],['../struct_mouse_click_block.html#aab54adb9e308ae6a8ec02f75243fcf49',1,'MouseClickBlock::y']]],
  ['y0_1',['y0',['../structsprite__box.html#ae1a0831b469684ab9c27bf961f24c207',1,'sprite_box']]],
  ['y1_2',['y1',['../structsprite__box.html#aa819f3b990d687abf0e32d1f56fce33b',1,'sprite_box']]],
  ['ydiv_3',['ydiv',['../structsprite__factors.html#a33b8a1a0f0fde6ec81f739dbb7ace7b4',1,'sprite_factors']]],
  ['ymag_4',['ymag',['../structsprite__factors.html#a74e2157a32d56e9beb0f4a632523406b',1,'sprite_factors']]],
  ['yoffset_5',['yOffset',['../struct_key_pressed_block.html#a105606079f2706f4b03bae90026bd849',1,'KeyPressedBlock']]]
];
