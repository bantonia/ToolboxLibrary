var struct_wimp_palette_str =
[
    [ "c", "struct_wimp_palette_str.html#aecd397a5c4cdb5dd0e24fcd79936d51f", null ],
    [ "mouse1", "struct_wimp_palette_str.html#a98a096ab5c149d3968d436f14b5ed90a", null ],
    [ "mouse2", "struct_wimp_palette_str.html#a0dc58ca17edca40d6d1d768fe37e5885", null ],
    [ "mouse3", "struct_wimp_palette_str.html#a2a1ed4ffa4d21d1fc189b81af5ab3728", null ],
    [ "screenborder", "struct_wimp_palette_str.html#a2b7822ed2675aeb03b68f78c3d47367d", null ]
];