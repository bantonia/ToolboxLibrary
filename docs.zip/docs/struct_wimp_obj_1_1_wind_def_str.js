var struct_wimp_obj_1_1_wind_def_str =
[
    [ "WindDefStr", "struct_wimp_obj_1_1_wind_def_str.html#ad56157203d6531a6ec56136a12bc4ef1", null ],
    [ "~WindDefStr", "struct_wimp_obj_1_1_wind_def_str.html#a2dd42f2d263b18b20b5f68cf0a632e27", null ],
    [ "operator delete", "struct_wimp_obj_1_1_wind_def_str.html#afa1a550a5544cbbefb2e4d17eba720de", null ],
    [ "operator new", "struct_wimp_obj_1_1_wind_def_str.html#ae243c753bb1ed7cb3e97544caf5fa2c3", null ],
    [ "operator new", "struct_wimp_obj_1_1_wind_def_str.html#a16c4cd3e36b0413eed2cf5baa9a3b210", null ],
    [ "operator new", "struct_wimp_obj_1_1_wind_def_str.html#ac88d2d97128de3a4554246f8f8662266", null ],
    [ "window", "struct_wimp_obj_1_1_wind_def_str.html#a81852984e5105abf7147ad7564663b88", null ]
];