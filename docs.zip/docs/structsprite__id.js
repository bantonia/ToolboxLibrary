var structsprite__id =
[
    [ "addr", "structsprite__id.html#ac11dca3f9ca428bb62f1f4c008089ef3", null ],
    [ "name", "structsprite__id.html#abcc66e6783439338c5ed6fc7a5b463c9", null ],
    [ "s", "structsprite__id.html#a402246810a6ea988c3aa81b475a4b1dc", null ],
    [ "tag", "structsprite__id.html#a42a9af8b288ffed27039c8181341ed09", null ]
];