var structsprite__pgm =
[
    [ "p0", "structsprite__pgm.html#a21d406f1dfe6d11758d6f25305a6beaa", null ],
    [ "p1", "structsprite__pgm.html#ac489bed2f4dcb6b10f5dcb0176965be4", null ],
    [ "p2", "structsprite__pgm.html#a4f328acc4bc8549a1532a0d4395de415", null ],
    [ "p3", "structsprite__pgm.html#a7b0254de528668ff77356af359fc8908", null ]
];