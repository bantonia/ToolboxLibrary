var structsprite__factors =
[
    [ "xdiv", "structsprite__factors.html#a4308e455cdb9b4f980c8b98f48bdb448", null ],
    [ "xmag", "structsprite__factors.html#a5bf8eaeebad4465afad15b25b69b2304", null ],
    [ "ydiv", "structsprite__factors.html#a33b8a1a0f0fde6ec81f739dbb7ace7b4", null ],
    [ "ymag", "structsprite__factors.html#a74e2157a32d56e9beb0f4a632523406b", null ]
];