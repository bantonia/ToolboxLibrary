var class_error_report =
[
    [ "errorEnv", "class_error_report.html#a8ce273bb4b177794aa5abcfb823ed0ac", [
      [ "CONSOLE", "class_error_report.html#a8ce273bb4b177794aa5abcfb823ed0acaf6a7f34d6764b3055346c1403933617f", null ],
      [ "WIMP", "class_error_report.html#a8ce273bb4b177794aa5abcfb823ed0aca9eca3cd03fa1303fa7b3454cbca4cbb8", null ]
    ] ],
    [ "ErrorReport", "class_error_report.html#a1ce036050ec4617283eff875995ca27a", null ],
    [ "~ErrorReport", "class_error_report.html#a6ec853c4b91e7cf38aa67e269131f06d", null ]
];