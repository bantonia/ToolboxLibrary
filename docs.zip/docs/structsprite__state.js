var structsprite__state =
[
    [ "r", "structsprite__state.html#ad2ac2b693f88cfc4513a214650db4d2e", null ]
];