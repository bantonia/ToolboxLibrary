var class_toolbox_colour_dlog_obj =
[
    [ "colourBlockHdr", "struct_toolbox_colour_dlog_obj_1_1colour_block_hdr.html", "struct_toolbox_colour_dlog_obj_1_1colour_block_hdr" ],
    [ "ColourModel", "class_toolbox_colour_dlog_obj.html#a9f2eae24b797a12eaf359a62957e92bd", [
      [ "RGB", "class_toolbox_colour_dlog_obj.html#a9f2eae24b797a12eaf359a62957e92bdaa5cd87ecac238d6f44938b835ae1bfe2", null ],
      [ "CMYK", "class_toolbox_colour_dlog_obj.html#a9f2eae24b797a12eaf359a62957e92bda90dfdc56e85a4d15f4b1bc73d6b58e15", null ],
      [ "HSV", "class_toolbox_colour_dlog_obj.html#a9f2eae24b797a12eaf359a62957e92bda0c0450e4a68317ea3ceec3d347e426f2", null ]
    ] ],
    [ "ToolboxColourDlogObj", "class_toolbox_colour_dlog_obj.html#a2ed10bb5bba623498f9143114fd187eb", null ],
    [ "ToolboxColourDlogObj", "class_toolbox_colour_dlog_obj.html#a7e344a24fdc9dc12e864ef48cd52e699", null ],
    [ "~ToolboxColourDlogObj", "class_toolbox_colour_dlog_obj.html#ae77c9eee698dc77be35d41ab95886854", null ],
    [ "clearFlags", "class_toolbox_colour_dlog_obj.html#a39033190647d4da0a9b839760277e418", null ],
    [ "getClassName", "class_toolbox_colour_dlog_obj.html#a8cce0f8e10371d391214af6ae54ee267", null ],
    [ "getClassType", "class_toolbox_colour_dlog_obj.html#a45a92ed4b4f564b38ad0f6f2719af657", null ],
    [ "getColourBlock", "class_toolbox_colour_dlog_obj.html#a6941e9cf262bba809edefdca5555684d", null ],
    [ "getColourBlock", "class_toolbox_colour_dlog_obj.html#ac8c6faaf1bbfed1988d5e72b80095710", null ],
    [ "getColourModel", "class_toolbox_colour_dlog_obj.html#a9d38f3ec2b6ff363299b637e2d308abd", null ],
    [ "getColourModel", "class_toolbox_colour_dlog_obj.html#a449fe9c4e6e6224bf45d02460340635d", null ],
    [ "getDialogueHandle", "class_toolbox_colour_dlog_obj.html#a66c6ad92561f5d3c7a90156af93fd8a8", null ],
    [ "getWimpHandle", "class_toolbox_colour_dlog_obj.html#a5c34a0b65a14a8e403215aaee0e0337b", null ],
    [ "hideNoneAvailable", "class_toolbox_colour_dlog_obj.html#a6eecd53a69e1fadaf435dffb3c098484", null ],
    [ "isNoneAvailable", "class_toolbox_colour_dlog_obj.html#ab0d7177f30022d5e541a231bcae419d6", null ],
    [ "readWimpHandle", "class_toolbox_colour_dlog_obj.html#ac31b05e8a8f1414c5913a20a88d19330", null ],
    [ "setColour", "class_toolbox_colour_dlog_obj.html#adcf8329f2bfdb0ed09b21f9db72c33d3", null ],
    [ "setColourModel", "class_toolbox_colour_dlog_obj.html#aba57835dc5ab1b67d807c264c4f35c77", null ],
    [ "setColourModel", "class_toolbox_colour_dlog_obj.html#a8b54d4784ad29735ec509997b2c8867b", null ],
    [ "setColourModel", "class_toolbox_colour_dlog_obj.html#a35eaa62bd3668e30329b5d1b499771b0", null ],
    [ "setFlags", "class_toolbox_colour_dlog_obj.html#a7f46f594e815cfb7277358d5086e6e49", null ],
    [ "setNoneAvailable", "class_toolbox_colour_dlog_obj.html#a90348933549ceb28b1c1eb913c3f44c5", null ],
    [ "setObjectId", "class_toolbox_colour_dlog_obj.html#a7676c9a21c51f52de1a9f7095de1d73e", null ],
    [ "showNoneAvailable", "class_toolbox_colour_dlog_obj.html#a2fc4d30d42cf583afaa150293ecbbabe", null ],
    [ "showProperties", "class_toolbox_colour_dlog_obj.html#aaa374648b5368feb34ccade2b2e5eddf", null ]
];