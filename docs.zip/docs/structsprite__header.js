var structsprite__header =
[
    [ "height", "structsprite__header.html#a4d72ca35b7a4c8daf8c977beb6ef2b8e", null ],
    [ "image", "structsprite__header.html#a70f54b811f52e36b7137def716ddb41e", null ],
    [ "lbit", "structsprite__header.html#a44efd538d9a1f4ba4e9149f75f60af40", null ],
    [ "mask", "structsprite__header.html#aef88ce8a3ca3450b76def70c98132476", null ],
    [ "mode", "structsprite__header.html#a4a8c3f0a1193281743853bbc021d41af", null ],
    [ "name", "structsprite__header.html#add5edbf7ce57dcfd33bf039825ed1a94", null ],
    [ "next", "structsprite__header.html#a0646e3cecede790c63ee19f1655723fb", null ],
    [ "rbit", "structsprite__header.html#a2ca2d016ad9274ab7e140fe52b8324cd", null ],
    [ "width", "structsprite__header.html#ac00101695c74ffe628d1a107275745e4", null ]
];