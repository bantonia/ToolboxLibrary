var class_toolbox_slider =
[
    [ "ToolboxSlider", "class_toolbox_slider.html#a839479b309bf0b99b56f734935bc232b", null ],
    [ "ToolboxSlider", "class_toolbox_slider.html#a958413dcd8c83c67a8baaa6fdf949242", null ],
    [ "ToolboxSlider", "class_toolbox_slider.html#a18093ac6b5793257bd55f20a8e15cf66", null ],
    [ "gadgetMethod", "class_toolbox_slider.html#a7dadb2fe57f4544933ae7475d425ef49", null ],
    [ "getBounds", "class_toolbox_slider.html#a1f2420ba36b2f468a8b8b3a956ff3053", null ],
    [ "getClassName", "class_toolbox_slider.html#a7339c3af46e0eb2e90b5f89d28955b99", null ],
    [ "getClassType", "class_toolbox_slider.html#ad638056db550438de67b9554d8f10d39", null ],
    [ "getColour", "class_toolbox_slider.html#a0a2cbdb72cc0f1558249157bd1e7bfb5", null ],
    [ "getValue", "class_toolbox_slider.html#a5346956eb7bbe613ed9e5b50cfde67fb", null ],
    [ "moveGadget", "class_toolbox_slider.html#a364eb1e32901ee26646702f9478c7a85", null ],
    [ "setBounds", "class_toolbox_slider.html#aed1aac7a24368a368a0b9044a14e04a6", null ],
    [ "setColour", "class_toolbox_slider.html#ada58ac90222898fb7c9a77a33d419cae", null ],
    [ "setComponentId", "class_toolbox_slider.html#a477b2017baa0e21e8a7eef2d904f8c3d", null ],
    [ "setFlags", "class_toolbox_slider.html#a75ed64eac1a424194cdbd96fa491e4ac", null ],
    [ "setFocus", "class_toolbox_slider.html#ab31f801b2ea7b8d1c7f4841a7edc7cb4", null ],
    [ "setGadgetFlags", "class_toolbox_slider.html#aec3c6e34567e9c99cfaac79051d80bbb", null ],
    [ "setHelpMessage", "class_toolbox_slider.html#ac38b53a6a579732022fdba4735b8a01a", null ],
    [ "setObjectId", "class_toolbox_slider.html#aa979ad6563cc6b6ea57f76ff21a0c744", null ],
    [ "setValue", "class_toolbox_slider.html#a0f90e0116b594d6c2556843a18accd1e", null ],
    [ "showProperties", "class_toolbox_slider.html#a8fa7f1177ce91d7488406da8496c31c9", null ]
];