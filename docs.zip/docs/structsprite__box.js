var structsprite__box =
[
    [ "x0", "structsprite__box.html#ac7fc838789ed8d952ca6d43d2654eb6f", null ],
    [ "x1", "structsprite__box.html#ac107090547938e9b8951e29772bd7d8f", null ],
    [ "y0", "structsprite__box.html#ae1a0831b469684ab9c27bf961f24c207", null ],
    [ "y1", "structsprite__box.html#aa819f3b990d687abf0e32d1f56fce33b", null ]
];