var structsprite__info =
[
    [ "height", "structsprite__info.html#a2083da83c773b4986949000f7741922b", null ],
    [ "mask", "structsprite__info.html#a5dc4e49e125dc4965b01288c64a8cbe0", null ],
    [ "mode", "structsprite__info.html#a4c667bedc95df5d3f2541977cffda585", null ],
    [ "width", "structsprite__info.html#ab674938b0c126f05ece917361e9cd7c2", null ]
];