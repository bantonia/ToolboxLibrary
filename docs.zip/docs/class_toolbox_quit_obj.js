var class_toolbox_quit_obj =
[
    [ "ToolboxQuitObj", "class_toolbox_quit_obj.html#a22e0e2aeb5340ad46c0336df352a3dc2", null ],
    [ "ToolboxQuitObj", "class_toolbox_quit_obj.html#abf16538c3816fda56da30b79cbd1c049", null ],
    [ "clearFlags", "class_toolbox_quit_obj.html#a11ec9c03d213de5440dcfa7fec5250fd", null ],
    [ "getClassName", "class_toolbox_quit_obj.html#a22b6e381c1ad4463de40f9309bf0d8c2", null ],
    [ "getClassType", "class_toolbox_quit_obj.html#a1fc39792f07da248622c8d6ad9e7dc28", null ],
    [ "getMessage", "class_toolbox_quit_obj.html#ac2edfbc7b0487edbcf4d5ea117afea59", null ],
    [ "getMessage", "class_toolbox_quit_obj.html#a0061544c262b7cef63a2b6e043d9aa77", null ],
    [ "getTitle", "class_toolbox_quit_obj.html#a0328b967f364edb82ffa3a401cce4bde", null ],
    [ "getTitle", "class_toolbox_quit_obj.html#a813d983d14f511e7bd152fc1f5d8919c", null ],
    [ "getWindowId", "class_toolbox_quit_obj.html#aa0dc22e9cdf84687d27e38bdededb757", null ],
    [ "setFlags", "class_toolbox_quit_obj.html#a02bafcc628bc62563bfce7439b4c72b1", null ],
    [ "setMessage", "class_toolbox_quit_obj.html#af3e9b11dcbc3f119da912d723da7b32b", null ],
    [ "setObjectId", "class_toolbox_quit_obj.html#a4e4fa806c33dd8a94b77d53cc33d7164", null ],
    [ "setTitle", "class_toolbox_quit_obj.html#a799721cdbfc9283eec265a1713ae1539", null ],
    [ "showProperties", "class_toolbox_quit_obj.html#a7c404a57dc2346442520d5d83dc39195", null ]
];