var struct_sprite_area_obj_1_1sprite_info__t =
[
    [ "height", "struct_sprite_area_obj_1_1sprite_info__t.html#adb518f049809b72b34563f25533cb121", null ],
    [ "maskStatus", "struct_sprite_area_obj_1_1sprite_info__t.html#ae9e19cb55864a8595711801c3b79a4e2", null ],
    [ "mode", "struct_sprite_area_obj_1_1sprite_info__t.html#a08b480162ce5fc3ed08ec3a9b09b5230", null ],
    [ "width", "struct_sprite_area_obj_1_1sprite_info__t.html#ae35a91f7abca3bcca4a63e06942cff10", null ]
];